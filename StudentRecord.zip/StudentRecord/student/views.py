from django.shortcuts import render
from django.views import View

def dashboard(request):
    return render(request, 'student/dashboard.html')